from flask import Flask, request

app = Flask(__name__)

@app.get("/")
def hello():
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    if client_ip and "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()

    return f"Hello World!\nYour IP address is: {client_ip}\n", 200, {
        "Content-Type": "text/plain; charset=utf-8"
    }

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
