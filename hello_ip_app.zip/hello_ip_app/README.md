# Hello IP App

A minimal Flask application that returns `Hello World!` and the client's IP address.

## Project structure

```text
hello_ip_app/
├── app/
│   └── main.py
├── .dockerignore
├── .gitignore
├── Dockerfile
├── README.md
└── requirements.txt
```

## Run locally

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app/main.py
```

Open:

http://localhost:8000

## Run with Docker

Build:

```bash
docker build -t hello-ip-app .
```

Run:

```bash
docker run --rm -p 8000:8000 hello-ip-app
```

Open:

http://localhost:8000

## Production

The Docker image uses Gunicorn and listens on port `8000`.

For a reverse proxy/load balancer, route traffic to:

```text
http://<container>:8000
```

The application also understands the `X-Forwarded-For` header, so it can report the original client IP when deployed behind a load balancer or reverse proxy.
